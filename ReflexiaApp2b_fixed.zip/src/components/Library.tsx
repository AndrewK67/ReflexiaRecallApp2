import React, { useMemo } from 'react';
import type { Entry, LearningResource } from '../types';
import { BookOpen, MonitorPlay, Zap, Bookmark } from 'lucide-react';

interface LibraryProps { entries: Entry[]; }

const Library: React.FC<LibraryProps> = ({ entries }) => {
  const resources = useMemo(() => {
    const all: LearningResource[] = [];
    entries.forEach(e => { if (e.type === 'REFLECTION' && e.learningPath) all.push(...e.learningPath); });
    const unique = new Map(); all.forEach(r => unique.set(r.title, r));
    return Array.from(unique.values()).reverse();
  }, [entries]);

  if (resources.length === 0) {
    return ( <div className="flex flex-col items-center justify-center h-64 text-slate-400 bg-slate-900/50 rounded-xl border border-slate-800"> <BookOpen size={32} className="mb-3 opacity-50" /> <p className="text-sm">Your Library is empty.</p> <p className="text-xs opacity-50">Complete reflections to generate resources.</p> </div> );
  }

  return (
    <div className="grid grid-cols-1 gap-4">
      {resources.map((res, i) => (
        <div key={i} className="bg-slate-800 border border-slate-700 p-4 rounded-xl flex gap-4 hover:bg-slate-750 transition-colors group">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 border-2 ${res.type === 'READ' ? 'bg-blue-900/20 border-blue-500 text-blue-400' : res.type === 'WATCH' ? 'bg-red-900/20 border-red-500 text-red-400' : 'bg-yellow-900/20 border-yellow-500 text-yellow-400'}`}> {res.type === 'READ' ? <BookOpen size={20} /> : res.type === 'WATCH' ? <MonitorPlay size={20} /> : <Zap size={20} />} </div>
          <div className="flex-1 min-w-0"> <div className="flex justify-between items-start"> <span className={`text-[10px] font-bold px-2 py-0.5 rounded mb-1 inline-block ${res.type === 'READ' ? 'bg-blue-900 text-blue-300' : res.type === 'WATCH' ? 'bg-red-900 text-red-300' : 'bg-yellow-900 text-yellow-300'}`}>{res.type}</span> <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity"> <Bookmark size={14} className="text-slate-400 hover:text-white cursor-pointer" /> </div> </div> <h3 className="text-white font-bold text-sm truncate">{res.title}</h3> <p className="text-slate-400 text-xs mt-1 line-clamp-2">{res.description}</p> </div>
        </div>
      ))}
    </div>
  );
};
export default Library;