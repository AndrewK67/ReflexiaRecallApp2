import React, { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  CheckCircle,
  ChevronLeft,
  Layers,
  Loader2,
  Mic,
  Music,
  Music4,
  PenTool,
  Sparkles,
  StopCircle,
  Volume2,
  VolumeX,
} from "lucide-react";

import { MODEL_CONFIG, PROFESSION_CONFIG } from "../constants";
import { StageId } from "../types";
import type { MediaItem, ProfessionType, ReflectionEntry, ReflectionModel } from "../types";

import Guide from "./Guide";
import CanvasBoard from "./CanvasBoard";

import { analyzeReflection, getStageCoaching } from "../services/geminiService";
import { getOfflineStagePrompt } from "../data/offlinePrompts";

interface ReflectionFlowProps {
  onComplete: (entry: ReflectionEntry) => void;
  onCancel: () => void;
  profession: ProfessionType;
  aiEnabled?: boolean; // OFF by default if not provided
}

const MOODS = [
  { value: 1, label: "Rough", emoji: "😣" },
  { value: 2, label: "Down", emoji: "😕" },
  { value: 3, label: "Okay", emoji: "😐" },
  { value: 4, label: "Good", emoji: "🙂" },
  { value: 5, label: "Great", emoji: "😁" },
] as const;

class AudioEngine {
  ctx: AudioContext | null = null;
  oscillators: OscillatorNode[] = [];
  gainNodes: GainNode[] = [];
  isMuted = false;

  init() {
    if (this.ctx) return;
    const Ctx = (window.AudioContext || (window as any).webkitAudioContext) as typeof AudioContext | undefined;
    if (!Ctx) return;
    this.ctx = new Ctx();
  }

  resumeIfNeeded() {
    if (this.ctx?.state === "suspended") this.ctx.resume();
  }

  playTone(stageIndex: number) {
    if (!this.ctx || this.isMuted) return;
    this.stop();
    const baseFreqs = [110, 140, 180, 220, 260, 300];
    const baseFreq = baseFreqs[stageIndex] ?? 110;
    this.createOscillator(baseFreq, -1);
    this.createOscillator(baseFreq + 4, 1);
  }

  private createOscillator(freq: number, pan: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const panner = this.ctx.createStereoPanner();

    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

    gain.gain.setValueAtTime(0, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.05, this.ctx.currentTime + 1.2);

    panner.pan.value = pan;

    osc.connect(gain);
    gain.connect(panner);
    panner.connect(this.ctx.destination);

    osc.start();

    this.oscillators.push(osc);
    this.gainNodes.push(gain);
  }

  stop() {
    if (!this.ctx) return;
    this.gainNodes.forEach((g) => {
      try {
        g.gain.linearRampToValueAtTime(0, this.ctx!.currentTime + 0.4);
      } catch {}
    });

    setTimeout(() => {
      try {
        this.oscillators.forEach((o) => o.stop());
      } catch {}
      this.oscillators = [];
      this.gainNodes = [];
    }, 450);
  }

  toggleMute(muted: boolean) {
    this.isMuted = muted;
    if (muted) this.stop();
  }
}

const audioEngine = new AudioEngine();

function safeModelLabel(model: ReflectionModel): string {
  return (MODEL_CONFIG as any)?.[model]?.label ?? model;
}

function safeModelStages(model: ReflectionModel) {
  return (MODEL_CONFIG as any)?.[model]?.stages ?? [];
}

export default function ReflectionFlow({ onComplete, onCancel, profession, aiEnabled }: ReflectionFlowProps) {
  const AI_ON = aiEnabled === true; // ✅ OFF by default

  const [selectedModel, setSelectedModel] = useState<ReflectionModel | null>(null);
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [mood, setMood] = useState<number | undefined>(undefined);

  const [attachments, setAttachments] = useState<MediaItem[]>([]);
  const [showCanvas, setShowCanvas] = useState(false);

  const [showInsight, setShowInsight] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);

  const [isCoaching, setIsCoaching] = useState(false);
  const [coachTip, setCoachTip] = useState<string | null>(null);

  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(false);

  const recognitionRef = useRef<any>(null);
  const baseTextRef = useRef<string>("");

  const activeStages = selectedModel ? safeModelStages(selectedModel) : [];
  const currentStage = activeStages[currentStageIndex];
  const isLastStage = activeStages.length > 0 && currentStageIndex === activeStages.length - 1;
  const isFinished = activeStages.length > 0 && currentStageIndex >= activeStages.length;

  let guideState: "idle" | "listening" | "thinking" | "speaking" = "idle";
  if (isListening) guideState = "listening";
  else if (isCoaching || isAnalyzing) guideState = "thinking";
  else if (isSpeaking) guideState = "speaking";

  useEffect(() => {
    return () => {
      try {
        window.speechSynthesis?.cancel();
      } catch {}
      audioEngine.stop();
      recognitionRef.current?.stop?.();
    };
  }, []);

  useEffect(() => {
    setCoachTip(null);
    cancelSpeech();

    if (isAudioEnabled && !isFinished && selectedModel) {
      audioEngine.init();
      audioEngine.resumeIfNeeded();
      audioEngine.playTone(currentStageIndex);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStageIndex, isAudioEnabled, isFinished, selectedModel]);

  const cancelSpeech = () => {
    try {
      window.speechSynthesis?.cancel();
    } catch {}
    setIsSpeaking(false);
  };

  const speakText = (text: string) => {
    if (!text) return;
    if (!("speechSynthesis" in window)) return;

    cancelSpeech();

    setIsSpeaking(true);
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.0;
    u.pitch = 1.05;
    u.onend = () => setIsSpeaking(false);
    u.onerror = () => setIsSpeaking(false);

    try {
      window.speechSynthesis.speak(u);
    } catch {
      setIsSpeaking(false);
    }
  };

  const toggleAudioAtmosphere = () => {
    const next = !isAudioEnabled;
    setIsAudioEnabled(next);

    if (next) {
      audioEngine.init();
      audioEngine.isMuted = false;
      audioEngine.resumeIfNeeded();
      audioEngine.playTone(currentStageIndex);
    } else {
      audioEngine.toggleMute(true);
    }
  };

  const toggleListening = () => {
    if (!currentStage) return;

    if (isListening) {
      recognitionRef.current?.stop?.();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice dictation is not supported in this browser.");
      return;
    }

    cancelSpeech();
    baseTextRef.current = answers[currentStage.id] || "";

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = "en-US";

    rec.onresult = (event: any) => {
      let transcript = "";
      for (let i = 0; i < event.results.length; i++) transcript += event.results[i][0].transcript;
      const base = baseTextRef.current;
      const sep = base && !base.endsWith(" ") && transcript ? " " : "";
      const nextText = base + sep + transcript;
      setAnswers((prev) => ({ ...prev, [currentStage.id]: nextText }));
    };

    rec.onerror = () => setIsListening(false);
    rec.onend = () => setIsListening(false);

    recognitionRef.current = rec;
    rec.start();
    setIsListening(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (!currentStage) return;
    setAnswers((prev) => ({ ...prev, [currentStage.id]: e.target.value }));
  };

  const handleAIHelp = async () => {
    if (!currentStage || !selectedModel) return;
    const text = (answers[currentStage.id] || "").trim();

    // ✅ AI OFF → offline guidance
    if (!AI_ON) {
      const offline = getOfflineStagePrompt(selectedModel, currentStage.id, profession);
      const msg = `${offline.title}\n\n${offline.prompt}`;
      setCoachTip(msg);
      speakText(msg);
      return;
    }

    if (text.length < 3) {
      const msg = "Start typing first, and I’ll help you explore further.";
      setCoachTip(msg);
      speakText(msg);
      return;
    }

    setIsCoaching(true);
    try {
      const tip = await getStageCoaching(currentStage.id, text, profession);
      setCoachTip(tip);
      speakText(tip);
    } finally {
      setIsCoaching(false);
    }
  };

  const handleNext = () => {
    if (!currentStage) return;
    if (isLastStage) audioEngine.stop();
    setCurrentStageIndex((prev) => prev + 1);
  };

  const resetToSelector = () => {
    setSelectedModel(null);
    setCurrentStageIndex(0);
    setAnswers({});
    setMood(undefined);
    setCoachTip(null);
    setShowInsight(false);
    setAnalysisResult(null);
    setIsAnalyzing(false);
    setIsCoaching(false);
    setIsListening(false);
    setIsSpeaking(false);
    audioEngine.stop();
  };

  const handleBack = () => {
    if (selectedModel && currentStageIndex > 0) {
      setCurrentStageIndex((prev) => prev - 1);
      return;
    }
    if (selectedModel && currentStageIndex === 0) {
      resetToSelector();
      return;
    }
    onCancel();
  };

  const handleStageJump = (idx: number) => setCurrentStageIndex(idx);

  const handleUnlockInsight = async () => {
    if (!selectedModel) return;
    setShowInsight(true);

    if (analysisResult) return;

    // ✅ AI OFF → offline summary
    if (!AI_ON) {
      const answered = Object.entries(answers)
        .filter(([, v]) => (v || "").trim().length > 0)
        .map(([k, v]) => `• ${k}: ${v.trim()}`)
        .slice(0, 10)
        .join("\n");

      const offline =
        `AI is OFF.\n\nHere’s a clean summary of what you wrote:\n` +
        `${answered || "• (No text yet)"}\n\n` +
        `Next step: choose 1 small action you can actually do in the next 24 hours.`;

      setAnalysisResult(offline);
      return;
    }

    setIsAnalyzing(true);
    try {
      const result = await analyzeReflection(answers, profession, selectedModel);
      setAnalysisResult(result);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSaveDrawing = (dataUrl: string) => {
    setShowCanvas(false);
    setAttachments((prev) => [
      ...prev,
      { id: Date.now().toString(), type: "SKETCH", url: dataUrl, timestamp: new Date().toLocaleTimeString(), name: "Sketch" },
    ]);
  };

  const handleSave = () => {
    if (!selectedModel) return;

    const entry: ReflectionEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      type: "REFLECTION",
      model: selectedModel,
      answers,
      mood,
      aiInsight: analysisResult || undefined,
      attachments: attachments.length ? attachments : undefined,
      cpd:
        profession !== "NONE"
          ? { timeSpentMinutes: 15, type: "INDIVIDUAL", standardsMatched: [] }
          : undefined,
    };

    onComplete(entry);
  };

  if (showCanvas) return <CanvasBoard onSave={handleSaveDrawing} onCancel={() => setShowCanvas(false)} />;

  // ✅ FIXED: Real model selector UI (no placeholder text)
  if (!selectedModel) {
    const models: ReflectionModel[] = ["GIBBS", "SBAR", "ERA", "ROLFE", "STAR", "SOAP", "MORNING", "EVENING", "FREE"];

    return (
      <div className="h-full bg-slate-50 flex flex-col animate-in fade-in duration-300 nav-safe">
        <div className="p-6 pt-10 bg-white border-b border-slate-200">
          <div className="flex items-center justify-between">
            <button
              onClick={onCancel}
              className="p-3 bg-white rounded-full hover:bg-slate-100 shadow-sm border border-slate-100 transition-colors"
              title="Back"
            >
              <ChevronLeft className="text-slate-600" size={22} />
            </button>

            <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <Layers className="text-indigo-600" /> Select Framework
            </h1>

            <div className="w-12" />
          </div>

          <div className="mt-3 text-xs text-slate-500">
            Profession: <span className="font-bold text-slate-700">{PROFESSION_CONFIG?.[profession]?.label ?? "Unknown"}</span>
            <span className="mx-2">•</span>
            AI: <span className={`font-bold ${AI_ON ? "text-indigo-600" : "text-slate-500"}`}>{AI_ON ? "ON" : "OFF"}</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 pb-40 custom-scrollbar">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {models.map((m) => (
              <button
                key={m}
                onClick={() => {
                  setSelectedModel(m);
                  setCurrentStageIndex(0);
                  setAnswers({});
                  setMood(undefined);
                  setCoachTip(null);
                  setAnalysisResult(null);
                  setShowInsight(false);
                }}
                className="text-left bg-white rounded-3xl border border-slate-200 p-5 hover:border-indigo-500 hover:shadow-lg transition"
              >
                <div className="flex items-center justify-between">
                  <div className="text-sm font-extrabold text-slate-800">{safeModelLabel(m)}</div>
                  <div className="text-[10px] font-bold text-slate-400">{safeModelStages(m).length} stages</div>
                </div>
                <div className="mt-2 text-xs text-slate-500 leading-relaxed">
                  Tap to start. You can use voice dictation, and optional coaching if AI is enabled.
                </div>
                <div className="mt-4 flex items-center gap-2 text-xs font-bold text-indigo-600">
                  Start <ArrowRight size={16} />
                </div>
              </button>
            ))}
          </div>

          <div className="mt-6 bg-white rounded-3xl border border-slate-200 p-5">
            <div className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Sparkles className="text-indigo-500" size={18} /> Tip
            </div>
            <div className="mt-2 text-xs text-slate-500">
              If AI is OFF, the app uses built-in prompts for each stage (no internet required).
              Turn AI ON in <span className="font-bold">Profile → Neural Link</span>.
            </div>
          </div>
        </div>
      </div>
    );
  }

  // FINISHED VIEW
  if (isFinished) {
    return (
      <div className="flex flex-col h-full bg-slate-50 animate-in fade-in duration-300 nav-safe">
        <div className="flex-1 overflow-y-auto p-6 flex flex-col items-center justify-center custom-scrollbar pb-28">
          <div className="mb-8 scale-110">
            <Guide stageId={null} state={guideState} />
          </div>

          <div className="text-center mb-10">
            <h2 className="text-3xl font-light text-slate-800 mb-2">Complete</h2>
            <p className="text-slate-400 text-lg">Your reflection is ready to save.</p>
          </div>

          <div className="w-full max-w-md space-y-4">
            {!showInsight ? (
              <button
                onClick={handleUnlockInsight}
                className="w-full py-4 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-50 transition-colors"
              >
                <Sparkles size={18} className="text-indigo-500" />
                Unlock Insight {AI_ON ? "" : "(Offline)"}
              </button>
            ) : (
              <div className="w-full bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-bold text-slate-800 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-indigo-500" /> Insight
                  </h3>

                  {!!analysisResult && (
                    <button
                      onClick={() => (isSpeaking ? cancelSpeech() : speakText(analysisResult))}
                      className="p-2 rounded-full bg-slate-100 text-slate-500 hover:text-indigo-600 transition-colors"
                      title={isSpeaking ? "Stop" : "Read aloud"}
                    >
                      {isSpeaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
                    </button>
                  )}
                </div>

                {isAnalyzing ? (
                  <div className="flex flex-col items-center justify-center py-8 text-indigo-500 gap-3">
                    <Loader2 className="w-6 h-6 animate-spin" />
                    <span className="text-xs font-bold uppercase tracking-widest opacity-70">Processing…</span>
                  </div>
                ) : (
                  <div className="max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                    <p className="text-slate-700 leading-relaxed text-sm whitespace-pre-line">{analysisResult}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="p-6 pb-8 bg-white border-t border-slate-200">
          <button
            onClick={handleSave}
            className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-slate-800 transition"
          >
            <CheckCircle size={20} />
            Save Reflection
          </button>
        </div>
      </div>
    );
  }

  if (!currentStage) {
    return (
      <div className="h-full bg-slate-50 flex flex-col items-center justify-center p-6 nav-safe">
        <p className="text-slate-500 text-center max-w-xs">Stage not found. Please go back and choose a framework again.</p>
        <button onClick={resetToSelector} className="mt-4 px-4 py-2 rounded-xl bg-slate-900 text-white">
          Back to frameworks
        </button>
      </div>
    );
  }

  const stageId = currentStage.id;

  const showMoodRow =
    stageId === StageId.Feelings ||
    stageId === StageId.ROLFE_What ||
    stageId === StageId.ERA_Experience ||
    stageId === StageId.STAR_Situation ||
    stageId === StageId.SOAP_Subjective ||
    stageId === StageId.MORNING_Energy;

  const showDrawButton = stageId === StageId.Feelings || stageId === StageId.ERA_Experience;

  return (
    <div className="flex flex-col h-full relative overflow-hidden bg-slate-50 nav-safe">
      <div className="absolute top-0 left-0 w-full h-full opacity-40 pointer-events-none" style={{ background: `linear-gradient(to bottom, ${currentStage.hex}20, transparent)` }} />

      <div className="flex items-center justify-between p-6 z-20 pt-8">
        <button
          onClick={handleBack}
          className="p-3 bg-white/80 backdrop-blur rounded-full shadow-sm text-slate-600 hover:text-slate-900 transition-all"
          title="Back"
        >
          <ChevronLeft size={22} />
        </button>

        <div className="flex items-center gap-1 bg-white/70 backdrop-blur-md p-1.5 rounded-full shadow-sm border border-white/50">
          {activeStages.map((_: any, idx: number) => (
            <button
              key={idx}
              onClick={() => handleStageJump(idx)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                idx === currentStageIndex ? "w-8 bg-slate-800" : idx < currentStageIndex ? "bg-slate-400" : "bg-slate-200"
              }`}
              aria-label={`Jump to stage ${idx + 1}`}
              title={`Stage ${idx + 1}`}
            />
          ))}
        </div>

        <button
          onClick={toggleAudioAtmosphere}
          className={`p-3 rounded-full transition-all shadow-sm ${isAudioEnabled ? "bg-white text-indigo-600" : "bg-white/60 text-slate-400 hover:bg-white"}`}
          title={isAudioEnabled ? "Audio on" : "Audio off"}
        >
          {isAudioEnabled ? <Music4 size={18} className="animate-pulse" /> : <Music size={18} />}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto w-full px-6 z-10 pb-10 custom-scrollbar">
        <div className="flex flex-col items-center justify-center min-h-full py-2">
          <div className="mb-8 shrink-0">
            <Guide stageId={currentStage.id} state={guideState} />
          </div>

          <div key={currentStage.id} className="w-full max-w-md animate-in slide-in-from-bottom-5 fade-in duration-300 shrink-0">
            <div className="text-center mb-7">
              <span className="inline-block text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full bg-white border border-slate-100 shadow-sm mb-4 text-slate-500">
                {safeModelLabel(selectedModel)} • Stage {currentStageIndex + 1}/{activeStages.length}
              </span>

              <h2 className="text-3xl font-bold text-slate-800 leading-tight mb-2">{currentStage.prompt}</h2>

              {!AI_ON && <div className="mt-2 text-xs text-slate-500">AI is <span className="font-bold">OFF</span> — using offline prompts.</div>}

              {coachTip && (
                <div className="mt-5 bg-white rounded-3xl p-5 border border-slate-200 shadow-sm text-left">
                  <div className="flex justify-between items-start gap-2 mb-2">
                    <div className="flex items-center gap-2 text-indigo-600 text-xs font-bold uppercase tracking-widest">
                      <Sparkles className="w-4 h-4" />
                      <span>{AI_ON ? "AI Insight" : "Offline Prompt"}</span>
                    </div>
                    <button
                      onClick={() => (isSpeaking ? cancelSpeech() : speakText(coachTip))}
                      className="text-slate-300 hover:text-indigo-600 transition-colors"
                      title={isSpeaking ? "Stop" : "Read aloud"}
                    >
                      {isSpeaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
                    </button>
                  </div>
                  <div className="max-h-56 overflow-y-auto pr-2 custom-scrollbar text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                    {coachTip}
                  </div>
                </div>
              )}
            </div>

            {showMoodRow && (
              <div className="flex justify-between bg-white p-2 rounded-2xl shadow-sm border border-slate-100 mb-4">
                {MOODS.map((m) => (
                  <button
                    key={m.value}
                    onClick={() => setMood(m.value)}
                    className={`text-2xl p-3 rounded-xl transition-all ${
                      mood === m.value ? "bg-slate-100 scale-110 shadow-inner" : "hover:bg-slate-50 hover:scale-105 grayscale hover:grayscale-0"
                    }`}
                    title={m.label}
                  >
                    {m.emoji}
                  </button>
                ))}
              </div>
            )}

            <div className="relative">
              <textarea
                className={`w-full h-56 p-6 rounded-[2rem] border-0 shadow-xl shadow-slate-200/50 resize-none text-slate-700 placeholder:text-slate-300 transition-all text-lg leading-relaxed focus:outline-none focus:ring-4 ${
                  isListening ? "ring-red-100 bg-red-50/30" : "bg-white focus:ring-indigo-100"
                }`}
                placeholder={isListening ? "Listening..." : "Type or tap the mic to speak..."}
                value={answers[currentStage.id] || ""}
                onChange={handleInputChange}
                autoFocus
              />

              <div className="absolute bottom-4 right-4 flex gap-2">
                <button
                  onClick={handleAIHelp}
                  className={`w-10 h-10 rounded-full transition-all shadow-sm flex items-center justify-center ${
                    AI_ON ? "bg-indigo-50 text-indigo-600 hover:bg-indigo-100 hover:scale-110" : "bg-slate-100 text-slate-400 hover:bg-slate-200"
                  }`}
                  title={AI_ON ? "Get AI help" : "Offline help (AI is off)"}
                >
                  {isCoaching ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                </button>

                {showDrawButton && (
                  <button
                    onClick={() => setShowCanvas(true)}
                    className="w-10 h-10 rounded-full bg-cyan-50 text-cyan-600 hover:bg-cyan-100 hover:scale-110 transition-all shadow-sm flex items-center justify-center"
                    title="Draw"
                  >
                    <PenTool className="w-5 h-5" />
                  </button>
                )}

                <button
                  onClick={toggleListening}
                  className={`w-10 h-10 rounded-full transition-all shadow-sm flex items-center justify-center ${
                    isListening ? "bg-red-500 text-white animate-pulse" : "bg-slate-100 text-slate-500 hover:bg-slate-200 hover:scale-110"
                  }`}
                  title="Voice dictation"
                >
                  {isListening ? <StopCircle className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 pb-8 bg-white/80 backdrop-blur-xl border-t border-slate-100 z-20">
        <button
          onClick={handleNext}
          disabled={!answers[currentStage.id] || (answers[currentStage.id] || "").trim().length === 0}
          className={`w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg transition-all transform active:scale-95 ${
            (answers[currentStage.id] || "").trim().length
              ? "bg-slate-900 text-white hover:bg-slate-800 hover:shadow-xl hover:-translate-y-1"
              : "bg-slate-100 text-slate-300 cursor-not-allowed"
          }`}
        >
          {isLastStage ? "Complete Reflection" : "Next Stage"}
          {isLastStage ? <CheckCircle size={20} /> : <ArrowRight size={20} />}
        </button>
      </div>
    </div>
  );
}
