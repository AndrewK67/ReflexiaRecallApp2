import React from 'react';
import { Lock, Sparkles, Zap, Crown } from 'lucide-react';
import { getTierFeatures } from '../services/subscriptionService';

interface PaywallProps {
  feature: string;
  reason: string;
  onUpgrade: () => void;
  onClose?: () => void;
}

/**
 * Paywall - Shown when user tries to access Pro features
 */
export function Paywall({ feature, reason, onUpgrade, onClose }: PaywallProps) {
  const proFeatures = getTierFeatures('pro');

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 rounded-3xl border border-white/20 max-w-md w-full p-6 animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-indigo-500 flex items-center justify-center mx-auto mb-4">
            <Crown size={32} className="text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Upgrade to Pro</h2>
          <p className="text-white/60">{reason}</p>
        </div>

        {/* Feature List */}
        <div className="mb-6 space-y-2">
          <p className="text-sm font-semibold text-white/80 mb-3">Pro includes:</p>
          {proFeatures.slice(0, 6).map((feat, idx) => (
            <div key={idx} className="flex items-start gap-2">
              <Sparkles size={16} className="text-cyan-400 flex-shrink-0 mt-0.5" />
              <span className="text-sm text-white/80">{feat}</span>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="mb-6">
          <div className="bg-white/5 rounded-2xl border border-white/10 p-4">
            <div className="flex items-baseline justify-center gap-2 mb-1">
              <span className="text-3xl font-bold text-white">£4.99</span>
              <span className="text-white/60">/month</span>
            </div>
            <p className="text-center text-xs text-white/50">or £49/year (save 17%)</p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="space-y-3">
          <button
            onClick={onUpgrade}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white font-bold text-lg hover:scale-105 transition active:scale-95 flex items-center justify-center gap-2"
          >
            <Zap size={20} />
            Upgrade Now
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="w-full py-3 px-6 rounded-2xl bg-white/5 border border-white/10 text-white/80 font-semibold hover:bg-white/10 transition"
            >
              Maybe Later
            </button>
          )}
        </div>

        {/* Trust Signals */}
        <div className="mt-6 pt-6 border-t border-white/10 text-center">
          <p className="text-xs text-white/40">
            ✓ 14-day money-back guarantee • ✓ Cancel anytime
          </p>
        </div>
      </div>
    </div>
  );
}

/**
 * Reflection Limit Paywall - Specific for free tier limit
 */
export function ReflectionLimitPaywall({ remaining, onUpgrade, onClose }: {
  remaining: number;
  onUpgrade: () => void;
  onClose?: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 rounded-3xl border border-white/20 max-w-md w-full p-6">
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-500 flex items-center justify-center mx-auto mb-4">
            <Lock size={32} className="text-amber-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">
            {remaining > 0 ? `${remaining} Reflections Left` : 'Reflection Limit Reached'}
          </h2>
          <p className="text-white/60">
            {remaining > 0
              ? `You're on the Free tier with a 50 reflection limit`
              : `You've reached the 50 reflection limit on the Free tier`}
          </p>
        </div>

        {remaining === 0 && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 mb-6">
            <p className="text-sm text-amber-200 text-center">
              Upgrade to Pro for unlimited reflections
            </p>
          </div>
        )}

        <div className="mb-6">
          <div className="bg-white/5 rounded-2xl border border-white/10 p-4 text-center">
            <div className="text-2xl font-bold text-white mb-1">
              Unlimited Reflections
            </div>
            <p className="text-white/60 text-sm">+ all Pro features</p>
            <div className="mt-3">
              <span className="text-lg text-white/80">from </span>
              <span className="text-3xl font-bold text-white">£4.99</span>
              <span className="text-white/60">/month</span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={onUpgrade}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white font-bold text-lg hover:scale-105 transition active:scale-95"
          >
            Upgrade to Pro
          </button>

          {onClose && remaining > 0 && (
            <button
              onClick={onClose}
              className="w-full py-3 px-6 rounded-2xl bg-white/5 border border-white/10 text-white/80 font-semibold hover:bg-white/10 transition"
            >
              Continue ({remaining} left)
            </button>
          )}
        </div>

        <div className="mt-6 text-center">
          <p className="text-xs text-white/40">
            ✓ 14-day money-back guarantee
          </p>
        </div>
      </div>
    </div>
  );
}

/**
 * Feature Locked Badge - Small inline upgrade prompt
 */
export function FeatureLockedBadge({ feature, onClick }: {
  feature: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-bold hover:scale-105 transition"
    >
      <Crown size={12} />
      <span>Pro</span>
    </button>
  );
}
