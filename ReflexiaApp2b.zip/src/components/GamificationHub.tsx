
import React from 'react';
import type { UserStats, Achievement } from '../types';
import { ACHIEVEMENTS } from '../constants';
import { Trophy, Lock, Flame, Star, Zap, Crown, Book, Library, Stethoscope, Moon, Sun, Award, Footprints } from 'lucide-react';

interface GamificationHubProps {
  stats: UserStats;
}

const IconMap: Record<string, any> = {
  Footprints, Flame, Zap, Crown, Book, Library, Stethoscope, Moon, Sun, Award
};

const GamificationHub: React.FC<GamificationHubProps> = ({ stats }) => {
  const unlockedIds = new Set(stats.achievements?.map(a => a.id) || []);
  const progressPercent = (stats.currentXP / stats.nextLevelXP) * 100;

  return (
    <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-xl border border-slate-800 mb-6 relative overflow-hidden">
       {/* Background Glow */}
       <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>

       <div className="flex items-center justify-between mb-6 relative z-10">
          <h2 className="text-xl font-bold flex items-center gap-2"><Trophy className="text-yellow-400" /> Achievements</h2>
          <div className="bg-slate-800 px-3 py-1 rounded-full text-xs font-bold border border-slate-700">
             Level {stats.level}
          </div>
       </div>

       {/* XP Bar */}
       <div className="mb-8 relative z-10">
          <div className="flex justify-between text-xs text-slate-400 mb-2 font-bold uppercase tracking-wider">
             <span>{stats.currentXP} XP</span>
             <span>{stats.nextLevelXP} XP</span>
          </div>
          <div className="h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
             <div className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-1000" style={{ width: `${progressPercent}%` }}></div>
          </div>
       </div>

       {/* Badges Grid */}
       <div className="grid grid-cols-4 gap-4 relative z-10">
          {ACHIEVEMENTS.map(badge => {
             const isUnlocked = unlockedIds.has(badge.id);
             const Icon = IconMap[badge.iconName] || Star;
             
             return (
               <div key={badge.id} className="flex flex-col items-center gap-2 group">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border-2 transition-all duration-300 relative ${
                     isUnlocked 
                     ? 'bg-indigo-900/50 border-indigo-400 text-indigo-300 shadow-[0_0_15px_rgba(99,102,241,0.3)]' 
                     : 'bg-slate-800 border-slate-700 text-slate-600 grayscale opacity-70'
                  }`}>
                     {isUnlocked ? <Icon size={24} /> : <Lock size={20} />}
                     {/* Tooltip */}
                     <div className="absolute bottom-full mb-2 bg-slate-900 text-white text-[10px] px-2 py-1 rounded border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20 pointer-events-none">
                        {badge.title}
                     </div>
                  </div>
               </div>
             );
          })}
       </div>
    </div>
  );
};

export default GamificationHub;
