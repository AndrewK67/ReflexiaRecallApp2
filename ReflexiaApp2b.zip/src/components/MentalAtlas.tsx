import React, { useMemo, useState } from 'react';
import type { Entry } from '../types';

interface MentalAtlasProps {
  entries: Entry[];
}

interface Node {
  id: string;
  label: string;
  value: number; // Frequency
  x: number;
  y: number;
  hue: number;
}

interface Link {
  source: Node;
  target: Node;
  strength: number;
}

const MentalAtlas: React.FC<MentalAtlasProps> = ({ entries }) => {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  // --- 1. DATA PROCESSING ---
  const { nodes, links } = useMemo(() => {
    const keywordCounts: Record<string, number> = {};
    const coOccurrences: Record<string, Record<string, number>> = {};

    // Tally keywords and build connections
    entries.forEach(entry => {
      if (entry.keywords && entry.keywords.length > 0) {
        // Count freq
        entry.keywords.forEach(k => {
          keywordCounts[k] = (keywordCounts[k] || 0) + 1;
        });

        // Track connections (if they appear in same entry)
        for (let i = 0; i < entry.keywords.length; i++) {
          for (let j = i + 1; j < entry.keywords.length; j++) {
            const a = entry.keywords[i];
            const b = entry.keywords[j];
            if (!coOccurrences[a]) coOccurrences[a] = {};
            if (!coOccurrences[b]) coOccurrences[b] = {};
            
            // Sort keys to ensure A-B is same as B-A
            const [k1, k2] = [a, b].sort();
            const pairKey = `${k1}|${k2}`; // Simplified logic for counting
            
            // We just need raw graph data, so we'll re-process below
          }
        }
      }
    });

    // Create Nodes
    let processedNodes: Node[] = Object.entries(keywordCounts)
      .sort(([, a], [, b]) => b - a) // Sort by freq desc
      .slice(0, 15) // Top 15 keywords
      .map(([key, count], index) => ({
        id: key,
        label: key,
        value: count,
        x: 0,
        y: 0,
        hue: (index * 137.5) % 360 // Golden angle for color distribution
      }));

    // Add "Self" center node
    const centerNode: Node = { id: 'SELF', label: 'YOU', value: 10, x: 200, y: 200, hue: 0 };
    processedNodes = [centerNode, ...processedNodes];

    // --- 2. LAYOUT ENGINE (Radial) ---
    const centerX = 200;
    const centerY = 200;
    
    // Assign positions based on rank
    processedNodes.forEach((node, i) => {
      if (node.id === 'SELF') return;
      
      const rank = i; // 1 to 15
      // Distribute in two orbits
      const orbitRadius = rank <= 5 ? 80 : 140; 
      const angleStep = rank <= 5 ? (Math.PI * 2) / 5 : (Math.PI * 2) / (processedNodes.length - 6);
      const angleOffset = rank <= 5 ? 0 : Math.PI / 4;
      
      const angle = (rank * angleStep) + angleOffset;
      
      node.x = centerX + Math.cos(angle) * orbitRadius;
      node.y = centerY + Math.sin(angle) * orbitRadius;
    });

    // Create Links (Star Topology for now + Co-occurrences)
    const processedLinks: Link[] = [];
    
    processedNodes.forEach((node) => {
      if (node.id === 'SELF') return;
      // Link everything to Self
      processedLinks.push({
        source: centerNode,
        target: node,
        strength: 0.2
      });
    });

    return { nodes: processedNodes, links: processedLinks };
  }, [entries]);

  if (entries.length === 0 || nodes.length <= 1) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-slate-400 bg-slate-900/50 rounded-xl border border-slate-800">
        <div className="w-12 h-12 rounded-full border-2 border-slate-700 mb-3 animate-pulse"></div>
        <p className="text-sm">Not enough data to map your mind.</p>
        <p className="text-xs opacity-50">Complete more reflections.</p>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-square max-w-md mx-auto bg-slate-900 rounded-full border border-slate-800 shadow-[0_0_50px_rgba(0,0,0,0.5)_inset] overflow-visible mb-6">
       {/* Background Grid */}
       <div className="absolute inset-0 opacity-20" style={{ 
          backgroundImage: 'radial-gradient(circle, #4f46e5 1px, transparent 1px)',
          backgroundSize: '20px 20px'
       }}></div>

       <svg viewBox="0 0 400 400" className="w-full h-full animate-in fade-in duration-1000">
          <defs>
            <filter id="glow-node" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Links */}
          {links.map((link, i) => (
             <line 
               key={i}
               x1={link.source.x} y1={link.source.y}
               x2={link.target.x} y2={link.target.y}
               stroke="white"
               strokeOpacity="0.1"
               strokeWidth="1"
             />
          ))}

          {/* Orbits */}
          <circle cx="200" cy="200" r="80" fill="none" stroke="white" strokeOpacity="0.05" strokeDasharray="4 4" />
          <circle cx="200" cy="200" r="140" fill="none" stroke="white" strokeOpacity="0.05" strokeDasharray="4 4" />

          {/* Nodes */}
          {nodes.map((node) => {
            const isSelf = node.id === 'SELF';
            const radius = isSelf ? 25 : Math.max(10, Math.min(20, node.value * 3));
            const color = isSelf ? '#ffffff' : `hsl(${node.hue}, 70%, 60%)`;
            const isHovered = hoveredNode === node.id;
            
            return (
              <g 
                key={node.id} 
                className="transition-all duration-300 cursor-pointer"
                onMouseEnter={() => setHoveredNode(node.id)}
                onMouseLeave={() => setHoveredNode(null)}
                style={{ transformOrigin: `${node.x}px ${node.y}px`, transform: isHovered ? 'scale(1.2)' : 'scale(1)' }}
              >
                {/* Glow Ring */}
                {isHovered && (
                  <circle cx={node.x} cy={node.y} r={radius + 5} fill="none" stroke={color} strokeWidth="2" opacity="0.5">
                    <animate attributeName="r" values={`${radius+5};${radius+10};${radius+5}`} dur="1.5s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.5;0;0.5" dur="1.5s" repeatCount="indefinite" />
                  </circle>
                )}

                {/* Main Body */}
                <circle 
                  cx={node.x} 
                  cy={node.y} 
                  r={radius} 
                  fill={isSelf ? 'url(#node-gradient-self)' : color}
                  fillOpacity={isSelf ? 1 : 0.8}
                  stroke={isSelf ? 'none' : 'white'}
                  strokeWidth={isSelf ? 0 : 1}
                  filter="url(#glow-node)"
                />
                
                {/* Label */}
                <text 
                  x={node.x} 
                  y={node.y + radius + 15} 
                  textAnchor="middle" 
                  fill="white" 
                  fontSize={isSelf ? 14 : 10}
                  fontWeight={isSelf || isHovered ? 'bold' : 'normal'}
                  opacity={isSelf || isHovered ? 1 : 0.7}
                  className="pointer-events-none"
                  style={{ textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}
                >
                  {node.label}
                </text>
                
                {/* Count (on hover) */}
                {isHovered && !isSelf && (
                   <text 
                     x={node.x} 
                     y={node.y - radius - 5}
                     textAnchor="middle"
                     fill={color}
                     fontSize="10"
                     fontWeight="bold"
                   >
                     x{node.value}
                   </text>
                )}
              </g>
            );
          })}

          <defs>
             <radialGradient id="node-gradient-self">
               <stop offset="0%" stopColor="#ffffff" />
               <stop offset="100%" stopColor="#6366f1" />
             </radialGradient>
          </defs>
       </svg>
    </div>
  );
};

export default MentalAtlas;