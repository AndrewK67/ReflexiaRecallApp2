import React, { useState, useEffect } from 'react';
import { Shield, Lock, Fingerprint, Unlock } from 'lucide-react';

interface PrivacyLockProps { onUnlock: () => void; userName: string; }

const PrivacyLock: React.FC<PrivacyLockProps> = ({ onUnlock, userName }) => {
  const [pin, setPin] = useState('');
  useEffect(() => { if (pin === '1234') onUnlock(); }, [pin]);
  return (
    <div className="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center text-white">
       <Lock size={48} className="mb-4 text-cyan-400" />
       <h1 className="text-xl font-bold mb-4">Locked</h1>
       <div className="grid grid-cols-3 gap-4">
         {[1,2,3,4,5,6,7,8,9].map(n => <button key={n} onClick={() => setPin(p => p + n)} className="w-16 h-16 rounded-full bg-slate-800 text-xl font-bold">{n}</button>)}
       </div>
    </div>
  );
};
export default PrivacyLock;