// src/services/gamificationService.ts
import type { Achievement, Entry, UserStats, ReflectionEntry } from "../types";
import { ACHIEVEMENTS } from "../constants";

export const gamificationService = {
  checkAchievements: (stats: UserStats, entries: Entry[]): Achievement[] => {
    const unlocked = Array.isArray(stats.achievements) ? [...stats.achievements] : [];
    const unlockedIds = new Set(unlocked.map((a) => a.id));
    const newUnlocks: Achievement[] = [];

    ACHIEVEMENTS.forEach((achievement) => {
      if (unlockedIds.has(achievement.id)) return;

      const ct = achievement.conditionType;
      const threshold = achievement.threshold ?? 0;

      let passed = false;

      switch (ct) {
        case "STREAK":
          passed = (stats.streak ?? 0) >= threshold;
          break;

        case "TOTAL_ENTRIES":
          passed = entries.length >= threshold;
          break;

        case "TOTAL_HOURS":
          passed = (stats.cpdMinutesTotal ?? 0) >= threshold;
          break;

        case "SPECIFIC_MODEL": {
          const model = achievement.meta;
          const count = entries.filter(
            (e) => e.type === "REFLECTION" && (e as ReflectionEntry).model === model
          ).length;
          passed = count >= threshold;
          break;
        }

        default:
          passed = false;
      }

      if (passed) {
        const earned: Achievement = { ...achievement, unlockedAt: new Date().toISOString() };
        newUnlocks.push(earned);
        unlocked.push(earned);
      }
    });

    // Mutate caller's stats for convenience (your storage layer can persist)
    stats.achievements = unlocked;

    return newUnlocks;
  },

  calculateStreak: (entries: Entry[]): number => {
    if (entries.length === 0) return 0;

    const sorted = [...entries].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    const today = new Date().setHours(0, 0, 0, 0);
    const lastEntryDate = new Date(sorted[0].date).setHours(0, 0, 0, 0);

    const diff = (today - lastEntryDate) / (1000 * 60 * 60 * 24);
    if (diff > 1) return 0;

    let streak = 1;
    let currentDate = lastEntryDate;

    for (let i = 1; i < sorted.length; i++) {
      const d = new Date(sorted[i].date).setHours(0, 0, 0, 0);
      if (d === currentDate) continue;
      if (currentDate - d === 86400000) {
        streak++;
        currentDate = d;
      } else {
        break;
      }
    }
    return streak;
  },
};
