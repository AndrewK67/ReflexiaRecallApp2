import React, { useMemo } from "react";

type GuideState = "idle" | "listening" | "thinking" | "speaking";

export type GuideProps = {
  /** stageId is usually your StageId enum value, but accept string to avoid breaking when types drift */
  stageId?: string | null;
  state?: GuideState;
  className?: string;
  /** Optional override colour for special screens (e.g. bio-rhythm phases). */
  customColor?: string;
};

/**
 * Guide (visual only)
 * CRITICAL: pointer-events are disabled so it can never block clicks on forms/buttons.
 */
export default function Guide({ stageId = null, state = "idle", className = "", customColor }: GuideProps) {
  const { fill, glowOpacity, ringOpacity, pulse } = useMemo(() => {
    const id = (stageId ?? "").toLowerCase();

    // Simple “meaningful” colour mapping without depending on a fragile enum.
    const byStage = () => {
      if (id.includes("feel")) return "#f87171"; // red
      if (id.includes("desc") || id.includes("situation")) return "#4ade80"; // green
      if (id.includes("eval") || id.includes("background")) return "#60a5fa"; // blue
      if (id.includes("anal") || id.includes("assessment")) return "#c084fc"; // purple
      if (id.includes("concl") || id.includes("action") || id.includes("recommend")) return "#fb923c"; // orange
      if (id.includes("plan")) return "#facc15"; // yellow
      if (id.includes("morning")) return "#06b6d4"; // cyan
      if (id.includes("evening")) return "#9333ea"; // violet
      if (id.includes("free")) return "#94a3b8"; // slate
      return "#67e8f9"; // default cyan-ish
    };

    const base = typeof customColor === "string" && customColor.trim() ? customColor : byStage();

    const styleByState: Record<GuideState, { glowOpacity: number; ringOpacity: number; pulse: boolean }> = {
      idle: { glowOpacity: 0.35, ringOpacity: 0.15, pulse: false },
      listening: { glowOpacity: 0.45, ringOpacity: 0.22, pulse: true },
      thinking: { glowOpacity: 0.60, ringOpacity: 0.28, pulse: true },
      speaking: { glowOpacity: 0.55, ringOpacity: 0.25, pulse: false },
    };

    return { fill: base, ...styleByState[state] };
  }, [stageId, state, customColor]);

  return (
    <div
      className={`guide-root ${className}`}
      aria-hidden="true"
      // Belt + braces: even if CSS is missing, this still prevents click-stealing.
      style={{ pointerEvents: "none" }}
    >
      <svg
        width="220"
        height="220"
        viewBox="0 0 200 200"
        style={{ pointerEvents: "none" }}
      >
        <defs>
          <filter id="guide-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Outer ring */}
        <circle
          cx="100"
          cy="100"
          r="82"
          fill="none"
          stroke="white"
          strokeOpacity={ringOpacity}
          strokeWidth="2"
        />

        {/* Glow */}
        <circle
          cx="100"
          cy="100"
          r="64"
          fill={fill}
          opacity={glowOpacity}
          filter="url(#guide-glow)"
        />

        {/* Core */}
        <circle
          cx="100"
          cy="100"
          r="54"
          fill={fill}
          opacity={0.85}
          className={pulse ? "guide-pulse" : ""}
        />

        {/* Small “activity” dots */}
        <circle cx="100" cy="26" r="3" fill="white" opacity="0.35" />
        <circle cx="174" cy="100" r="3" fill="white" opacity="0.35" />
        <circle cx="100" cy="174" r="3" fill="white" opacity="0.35" />
        <circle cx="26" cy="100" r="3" fill="white" opacity="0.35" />
      </svg>
    </div>
  );
}
