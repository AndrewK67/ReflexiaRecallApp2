// src/types.ts

/** -----------------------------
 * Core IDs / Enums
 * ------------------------------ */

export type ProfessionId =
  | "NONE"
  | "HEALTHCARE"
  | "EDUCATION"
  | "TEACHING"
  | "SOCIAL_CARE"
  | "SECURITY"
  | "POLICING"
  | "TRANSPORT"
  | "HOSPITALITY";

/**
 * We export StageId as a *value object* (so code can do StageId.ROLFE_What),
 * and also export the StageId *type* for strong typing if you want it.
 */
export const StageId = {
  // Generic / app stages
  Intent: "Intent",
  Options: "Options",
  Thoughts: "Thoughts",
  Learnings: "Learnings",
  Summary: "Summary",

  // ROLFE
  ROLFE_What: "ROLFE_What",
  ROLFE_SoWhat: "ROLFE_SoWhat",
  ROLFE_NowWhat: "ROLFE_NowWhat",

  // STAR
  STAR_Situation: "STAR_Situation",
  STAR_Task: "STAR_Task",
  STAR_Action: "STAR_Action",
  STAR_Result: "STAR_Result",

  // SOAP
  SOAP_Subjective: "SOAP_Subjective",
  SOAP_Objective: "SOAP_Objective",
  SOAP_Assessment: "SOAP_Assessment",
  SOAP_Plan: "SOAP_Plan",

  // Morning / Evening
  MORNING_Intention: "MORNING_Intention",
  MORNING_Gratitude: "MORNING_Gratitude",
  MORNING_Focus: "MORNING_Focus",

  EVENING_Wins: "EVENING_Wins",
  EVENING_Lessons: "EVENING_Lessons",
  EVENING_Release: "EVENING_Release",

  // Extended / custom
  CUSTOM_Stage1: "CUSTOM_Stage1",
  CUSTOM_Stage2: "CUSTOM_Stage2",
  CUSTOM_Stage3: "CUSTOM_Stage3",
} as const;

export type StageId = (typeof StageId)[keyof typeof StageId];

export type ReflectionModelId = "ROLFE" | "STAR" | "SOAP" | "MORNING" | "EVENING" | "CUSTOM";

export type MediaType = "AUDIO" | "VIDEO" | "IMAGE" | "TEXT" | "SKETCH";

/** -----------------------------
 * Crisis Types
 * ------------------------------ */

export type CrisisCategory =
  | "Immediate Safety"
  | "Mental Health"
  | "Addiction / Relapse"
  | "Domestic Abuse"
  | "Self-Harm"
  | "Grief / Trauma"
  | "Panic / Anxiety"
  | "Other";

export interface CrisisProtocolStep {
  title: string;
  body: string;
}

export interface CrisisProtocol {
  category: CrisisCategory;
  title: string;
  steps: CrisisProtocolStep[];
  /** Optional “call now” / external resource label */
  actionLabel?: string;
}

/** -----------------------------
 * Profession / CPD Types
 * ------------------------------ */

export interface ProfessionStandard {
  id: string; // e.g. "HCPC-1" / "TEACH-PS1" etc
  title: string;
  description?: string;
}

export interface ProfessionConfig {
  label: string;
  icon?: string;
  standards: ProfessionStandard[];
}

export interface CPDLog {
  minutes?: number;
  notes?: string;
  standardsMatched?: string[]; // standard IDs matched by this entry
}

export interface CompetencySummary {
  standardsMatched: string[];
}

/** -----------------------------
 * User / App State Types
 * ------------------------------ */

export interface UserProfile {
  id?: string;
  name: string;
  profession: ProfessionId;
  createdAt?: number;
  updatedAt?: number;
}

export interface UserStats {
  level: number;
  currentXP: number;
  nextLevelXP: number;
  streak: number;
  totalReflections: number;
  cpdMinutesTotal: number;
  achievements: string[];
}

/** -----------------------------
 * Content / Entries
 * ------------------------------ */

export interface MediaItem {
  id: string;
  type: MediaType;
  url?: string; // e.g. blob url, data url, remote url
  text?: string;
  createdAt: number;
  meta?: Record<string, unknown>;
}

export type EntryType = "reflection" | "incident";

export interface BaseEntry {
  id: string;
  type: EntryType;
  title: string;
  createdAt: number;
  updatedAt?: number;

  // common optional fields
  tags?: string[];
  mood?: number; // 1-10
  notes?: string;

  // CPD attachment (used by CompetencyMatrix etc)
  cpd?: CPDLog;

  // media attachment
  media?: MediaItem[];
}

export interface ReflectionEntry extends BaseEntry {
  type: "reflection";
  modelId: ReflectionModelId;
  stageId?: StageId;
  answers: Record<string, string>;
  aiInsight?: string;
}

export interface IncidentEntry extends BaseEntry {
  type: "incident";
  location?: string;
  description?: string;
  severity?: number; // 1-10
}

export type Entry = ReflectionEntry | IncidentEntry;

/** -----------------------------
 * Reflection Models
 * ------------------------------ */

export interface ReflectionStage {
  id: StageId;
  title: string;
  prompt: string;
  placeholder?: string;
}

export interface ReflectionModel {
  id: ReflectionModelId;
  title: string;
  description: string;
  stages: ReflectionStage[];
}

/** -----------------------------
 * Exports / Back-compat helpers
 * ------------------------------ */

export type ProfessionType = ProfessionId;
