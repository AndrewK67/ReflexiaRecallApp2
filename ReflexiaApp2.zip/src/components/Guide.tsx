
import React, { useState, useEffect } from 'react';
import { StageId } from '../types';

interface GuideProps {
  stageId?: StageId | null; // Null means neutral/resting state
  state?: 'idle' | 'listening' | 'thinking' | 'speaking';
  customColor?: string; // NEW: Allows Holodeck to override color for emotion
}

const Guide: React.FC<GuideProps> = ({ stageId, state = 'idle', customColor }) => {
  const [displayStage, setDisplayStage] = useState<StageId | null | undefined>(stageId);
  const [isMorphing, setIsMorphing] = useState(false);
  
  const isSpeaking = state === 'speaking';
  const isListening = state === 'listening';
  const isThinking = state === 'thinking';

  // Manage Transition Sequence (Liquid Morph)
  useEffect(() => {
    if (stageId !== displayStage) {
      // 1. Dissolve (Blur Out)
      setIsMorphing(true);
      
      const swapTimer = setTimeout(() => {
        // 2. Swap Geometry
        setDisplayStage(stageId);
        
        // 3. Reform (Blur In)
        // Small delay to ensure render cycle catches the swap before removing blur
        setTimeout(() => {
           setIsMorphing(false);
        }, 100);
        
      }, 300); // Wait for blur to max out

      return () => clearTimeout(swapTimer);
    }
  }, [stageId, displayStage]);

  // Hard Light Palette
  const getColors = (id: StageId | null | undefined) => {
    if (customColor) return customColor; // Priority Override

    switch (id) {
      // GIBBS
      case StageId.Description: return '#4ade80'; // Green
      case StageId.Feelings: return '#f87171'; // Red
      case StageId.Evaluation: return '#60a5fa'; // Blue
      case StageId.Analysis: return '#c084fc'; // Purple
      case StageId.Conclusion: return '#fb923c'; // Orange
      case StageId.ActionPlan: return '#facc15'; // Yellow
      
      // SBAR
      case StageId.SBAR_Situation: return '#f87171';
      case StageId.SBAR_Background: return '#60a5fa';
      case StageId.SBAR_Assessment: return '#c084fc';
      case StageId.SBAR_Recommendation: return '#4ade80';

      // ERA
      case StageId.ERA_Experience: return '#67e8f9';
      case StageId.ERA_Reflection: return '#818cf8';
      case StageId.ERA_Action: return '#fb923c';

      // ROLFE
      case StageId.ROLFE_What: return '#67e8f9';
      case StageId.ROLFE_SoWhat: return '#c084fc';
      case StageId.ROLFE_NowWhat: return '#facc15';

      // STAR
      case StageId.STAR_Situation: return '#f87171';
      case StageId.STAR_Task: return '#60a5fa';
      case StageId.STAR_Action: return '#4ade80';
      case StageId.STAR_Result: return '#fb923c';

      // SOAP
      case StageId.SOAP_Subjective: return '#c084fc';
      case StageId.SOAP_Objective: return '#60a5fa';
      case StageId.SOAP_Assessment: return '#facc15';
      case StageId.SOAP_Plan: return '#4ade80';

      // MORNING
      case StageId.MORNING_Energy: return '#06b6d4'; // Cyan
      case StageId.MORNING_Gratitude: return '#facc15'; // Yellow
      case StageId.MORNING_Intention: return '#4ade80'; // Green

      // EVENING
      case StageId.EVENING_Wins: return '#fb923c'; // Orange
      case StageId.EVENING_Growth: return '#9333ea'; // Purple
      case StageId.EVENING_Unwind: return '#3b82f6'; // Blue

      // FREE
      case StageId.FREE_Writing: return '#94a3b8'; // Slate/White

      default: return '#67e8f9'; // Cyan
    }
  };

  const targetHex = getColors(stageId);
  const currentShapeHex = customColor || getColors(displayStage);
  
  const uid = `guide-root-${Math.random().toString(36).substr(2, 5)}`;

  // --- 3D RENDER ENGINE ---
  const renderConstruct = (id: StageId | null | undefined) => {
    if (customColor) id = StageId.Feelings; // Default to Sphere for emotions

    // Common Face Styles
    const faceStyle = (opacity: number): React.CSSProperties => ({
      fill: currentShapeHex,
      stroke: "white",
      strokeWidth: 2,
      opacity: opacity,
      filter: `url(#${uid}-glow)`,
      vectorEffect: "non-scaling-stroke" as any,
      transition: 'fill 0.5s ease'
    });

    const faces: React.ReactNode[] = [];

    // --- GEOMETRY DEFINITIONS ---
    
    switch (id) {
      // CUBE
      case StageId.Evaluation:
      case StageId.SBAR_Background:
      case StageId.STAR_Task:
      case StageId.SOAP_Objective:
         faces.push(<path key="top" d="M100 40 L150 65 L100 90 L50 65 Z" style={faceStyle(0.6)} />);
         faces.push(<path key="left" d="M50 65 L100 90 L100 150 L50 125 Z" style={faceStyle(0.4)} />);
         faces.push(<path key="right" d="M100 90 L150 65 L150 125 L100 150 Z" style={faceStyle(0.2)} />);
         break;

      // PYRAMID
      case StageId.Description: 
      case StageId.SBAR_Recommendation:
      case StageId.ROLFE_NowWhat:
      case StageId.STAR_Action:
      case StageId.SOAP_Plan:
      case StageId.MORNING_Gratitude:
         // 4-sided pyramid rotated
         faces.push(<path key="left" d="M100 30 L50 130 L100 150 Z" style={faceStyle(0.4)} />);
         faces.push(<path key="right" d="M100 30 L100 150 L150 130 Z" style={faceStyle(0.2)} />);
         break;

      // CYLINDER
      case StageId.Analysis:
      case StageId.SBAR_Assessment:
      case StageId.ERA_Reflection:
      case StageId.ROLFE_SoWhat:
      case StageId.SOAP_Assessment:
      case StageId.EVENING_Growth:
         faces.push(<ellipse key="top" cx="100" cy="50" rx="50" ry="20" style={faceStyle(0.6)} />);
         faces.push(<path key="body" d="M50 50 L150 50 L150 130 A50 20 0 0 1 50 130 Z" style={faceStyle(0.3)} />);
         break;

      // CAPSULE
      case StageId.Conclusion:
      case StageId.ERA_Action:
      case StageId.STAR_Result:
      case StageId.MORNING_Intention:
         faces.push(<circle key="top" cx="100" cy="60" r="40" style={faceStyle(0.5)} />);
         faces.push(<circle key="bottom" cx="100" cy="140" r="40" style={faceStyle(0.3)} />);
         faces.push(<rect key="mid" x="60" y="60" width="80" height="80" style={faceStyle(0.4)} />);
         // Overlay highlight
         faces.push(<path key="shine" d="M90 40 Q70 60 70 140" fill="none" stroke="white" strokeWidth="4" opacity="0.6" />);
         break;

      // RECTANGLE / SLAB
      case StageId.ActionPlan:
      case StageId.FREE_Writing:
         faces.push(<path key="top" d="M60 60 L140 60 L160 40 L80 40 Z" style={faceStyle(0.6)} />);
         faces.push(<path key="front" d="M60 60 L140 60 L140 140 L60 140 Z" style={faceStyle(0.4)} />);
         faces.push(<path key="right" d="M140 60 L160 40 L160 120 L140 140 Z" style={faceStyle(0.2)} />);
         break;

      // SPHERE (Default)
      default:
         faces.push(<circle key="main" cx="100" cy="100" r="60" style={faceStyle(0.4)} />);
         // Inner Core
         faces.push(<circle key="core" cx="100" cy="100" r="30" fill="white" filter={`url(#${uid}-glow)`} opacity="0.8" />);
         // Orbit Rings (for sci-fi look)
         faces.push(<ellipse key="ring1" cx="100" cy="100" rx="70" ry="20" fill="none" stroke={currentShapeHex} strokeWidth="2" opacity="0.6" transform="rotate(20 100 100)" />);
         break;
    }

    return <g>{faces}</g>;
  };

  return (
    <div className={`relative w-64 h-64 flex items-center justify-center transition-all duration-500`}>
      
      {/* Ambient Floor Reflection */}
      <div 
        className={`absolute bottom-10 w-32 h-4 rounded-[100%] blur-xl transition-all duration-1000 ${isThinking ? 'scale-110 opacity-35' : 'scale-100 opacity-25'}`}
        style={{ backgroundColor: targetHex }}
      ></div>

      <svg 
        viewBox="0 0 200 200" 
        className={`w-full h-full transition-all duration-700 ease-in-out
          ${isThinking ? 'animate-bounce-gentle' : 'animate-float-3d'}
          ${isSpeaking ? 'scale-105' : 'scale-100'}
        `}
        style={{ 
           filter: `drop-shadow(0 0 30px ${targetHex}) blur(${isMorphing ? '12px' : '0px'})`, 
           transform: `scale(${isMorphing ? 0.8 : 1})`,
           overflow: 'visible'
        }}
      >
        <defs>
          <filter id={`${uid}-glow`} x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur1" />
            <feFlood floodColor={currentShapeHex} result="color" />
            <feComposite in="color" in2="blur1" operator="in" result="coloredBlur1" />
            <feMerge>
              <feMergeNode in="coloredBlur1" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* The 3D Construct */}
        <g style={{ transformOrigin: '100px 100px' }}>
           {renderConstruct(displayStage)}
        </g>
        
      </svg>
    </div>
  );
};

export default Guide;
