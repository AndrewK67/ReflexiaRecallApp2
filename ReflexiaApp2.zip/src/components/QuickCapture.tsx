// src/components/QuickCapture.tsx
import React, { useMemo, useState } from "react";
import type { Entry, GuardianBadge, IncidentEntry, MediaItem } from "../types";
import CanvasBoard from "./CanvasBoard";

type QuickCaptureProps = {
  aiEnabled: boolean;
  onComplete: (e: Entry) => void | Promise<void>;
  onCancel: () => void;
};

// Lightweight, offline-safe “guardian”.
// (This is NOT clinical advice — just a safety nudge when text looks high-risk.)
function localGuardianCheck(text: string): GuardianBadge | null {
  const t = (text || "").toLowerCase();

  const highSignals = [
    "suicide",
    "kill myself",
    "end it",
    "self harm",
    "can't go on",
    "overdose",
    "hurt myself",
  ];

  const medSignals = ["panic", "can't breathe", "hopeless", "worthless", "breakdown"];

  const hitHigh = highSignals.some((k) => t.includes(k));
  const hitMed = !hitHigh && medSignals.some((k) => t.includes(k));

  if (hitHigh) {
    return {
      riskLevel: "HIGH",
      summary: "This sounds urgent. Please don’t carry it alone.",
      suggestedActions: [
        "If you’re in immediate danger, call your local emergency number now.",
        "Reach out to a trusted person and stay with someone if possible.",
        "If you're in the UK & Ireland: Samaritans 116 123 (24/7).",
      ],
    };
  }

  if (hitMed) {
    return {
      riskLevel: "MED",
      summary: "This sounds heavy. A small support step could help.",
      suggestedActions: [
        "Do 60 seconds of slow breathing (4 in, 6 out).",
        "Message someone you trust: “Can you talk for 5 mins?”",
        "Write the next small step you can take today.",
      ],
    };
  }

  return null;
}

export default function QuickCapture({ aiEnabled, onComplete, onCancel }: QuickCaptureProps) {
  const [notes, setNotes] = useState("");
  const [tab, setTab] = useState<"TEXT" | "DRAW">("TEXT");
  const [drawingDataUrl, setDrawingDataUrl] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const guardianBadge = useMemo(() => {
    if (!aiEnabled) return null;
    return localGuardianCheck(notes);
  }, [aiEnabled, notes]);

  const save = async () => {
    const trimmed = notes.trim();
    if (!trimmed && !drawingDataUrl) return;

    setIsSaving(true);
    try {
      const media: MediaItem[] = [];
      if (drawingDataUrl) {
        media.push({
          id: `draw_${Date.now()}`,
          type: "DRAWING",
          dataUrl: drawingDataUrl,
          createdAt: new Date().toISOString(),
        });
      }

      const entry: IncidentEntry = {
        id: `incident_${Date.now()}`,
        type: "INCIDENT",
        date: new Date().toISOString(),
        notes: trimmed || "(Drawing only)",
        guardianBadge: guardianBadge ?? undefined,
        media: media.length ? media : undefined,
      };

      await onComplete(entry);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="h-full flex flex-col nav-safe">
      <div className="px-5 pt-6 pb-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-white text-xl font-extrabold">Quick Capture</div>
            <div className="text-white/70 text-sm">Grab the moment. Sort it later.</div>
          </div>
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded-xl bg-white/10 text-white text-sm font-semibold border border-white/15 hover:bg-white/15"
          >
            Close
          </button>
        </div>

        <div className="mt-4 flex gap-2">
          <button
            onClick={() => setTab("TEXT")}
            className={`px-4 py-2 rounded-full text-sm font-bold border ${
              tab === "TEXT"
                ? "bg-white text-slate-900 border-white"
                : "bg-white/10 text-white border-white/15 hover:bg-white/15"
            }`}
          >
            Text
          </button>
          <button
            onClick={() => setTab("DRAW")}
            className={`px-4 py-2 rounded-full text-sm font-bold border ${
              tab === "DRAW"
                ? "bg-white text-slate-900 border-white"
                : "bg-white/10 text-white border-white/15 hover:bg-white/15"
            }`}
          >
            Draw
          </button>
        </div>
      </div>

      <div className="flex-1 px-5 pb-5 overflow-y-auto custom-scrollbar">
        {tab === "TEXT" && (
          <>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="What just happened? What do you need to remember?"
              className="w-full min-h-[220px] rounded-3xl p-4 bg-white/10 text-white placeholder:text-white/40 border border-white/15 focus:outline-none focus:ring-2 focus:ring-white/30"
            />

            {guardianBadge && (
              <div className="mt-4 rounded-3xl p-4 border border-white/15 bg-white/10">
                <div className="text-white font-extrabold">
                  Guardian: {guardianBadge.riskLevel}
                </div>
                <div className="text-white/80 text-sm mt-1">{guardianBadge.summary}</div>
                {!!guardianBadge.suggestedActions?.length && (
                  <ul className="mt-3 text-white/80 text-sm list-disc pl-5 space-y-1">
                    {guardianBadge.suggestedActions.map((a) => (
                      <li key={a}>{a}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </>
        )}

        {tab === "DRAW" && (
          <div className="rounded-3xl border border-white/15 bg-white/5 overflow-hidden">
            <CanvasBoard
              height={520}
              onExport={(dataUrl) => setDrawingDataUrl(dataUrl)}
              initialDataUrl={drawingDataUrl ?? undefined}
            />
            <div className="p-3 flex items-center justify-between">
              <div className="text-white/70 text-xs">
                Tip: export saves your sketch into the capture.
              </div>
              <button
                onClick={() => setDrawingDataUrl(null)}
                className="px-3 py-2 rounded-xl bg-white/10 text-white text-xs font-bold border border-white/15 hover:bg-white/15"
              >
                Clear drawing
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bottom actions – safe above nav bar because parent has nav-safe */}
      <div className="px-5 pb-6">
        <button
          disabled={isSaving || (!notes.trim() && !drawingDataUrl)}
          onClick={save}
          className="w-full h-14 rounded-full font-extrabold text-lg border border-white/20 shadow-xl transition-all
                     bg-white text-slate-900 hover:opacity-95 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {isSaving ? "Saving…" : "Save Capture"}
        </button>
      </div>
    </div>
  );
}
