// src/components/Holodeck.tsx
import React, { useMemo, useState } from "react";
import { X, Sparkles, Play, RefreshCcw } from "lucide-react";

type Scenario = {
  id: string;
  title: string;
  description: string;
  prompt: string;
};

interface HolodeckProps {
  onClose: () => void;
  stage?: string; // optional (some versions of your app pass this)
}

export const Holodeck: React.FC<HolodeckProps> = ({ onClose }) => {
  const scenarios: Scenario[] = useMemo(
    () => [
      {
        id: "difficult-convo",
        title: "Difficult Conversation",
        description: "Rehearse a tough conversation with calm, clarity, and boundaries.",
        prompt:
          "Simulate a role-play. I want to practice a difficult conversation. Ask me who I'm speaking to, what I want, and what I'm afraid of. Keep it practical and supportive.",
      },
      {
        id: "high-pressure",
        title: "High Pressure Moment",
        description: "Practice decision-making when time is tight and stakes feel high.",
        prompt:
          "Guide me through a quick decision framework: clarify objective, risks, options, and one next step. Ask short questions, one at a time.",
      },
      {
        id: "confidence-reset",
        title: "Confidence Reset",
        description: "Reset your mindset after a knock or failure.",
        prompt:
          "Help me reset after a setback. Ask what happened, what story I'm telling myself, and what a wiser interpretation could be. End with 1 concrete next action.",
      },
    ],
    []
  );

  const [selected, setSelected] = useState<Scenario>(scenarios[0]);
  const [output, setOutput] = useState<string>("");

  const run = () => {
    setOutput(selected.prompt);
  };

  const reset = () => setOutput("");

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-3xl rounded-2xl bg-slate-950 border border-slate-800 shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-slate-200" />
            <div>
              <div className="text-slate-100 font-semibold">Holodeck</div>
              <div className="text-slate-400 text-xs">Practice scenarios in a safe space</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-900 text-slate-200"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3">
            <div className="text-slate-100 font-medium mb-2">Choose a scenario</div>
            <div className="space-y-2">
              {scenarios.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSelected(s);
                    setOutput("");
                  }}
                  className={[
                    "w-full text-left rounded-xl p-3 border transition",
                    selected.id === s.id
                      ? "border-slate-500 bg-slate-900/60"
                      : "border-slate-800 hover:bg-slate-900/40",
                  ].join(" ")}
                >
                  <div className="text-slate-100 font-semibold">{s.title}</div>
                  <div className="text-slate-400 text-sm">{s.description}</div>
                </button>
              ))}
            </div>

            <div className="flex gap-2 mt-3">
              <button
                onClick={run}
                className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-100 text-slate-950 font-semibold hover:bg-white"
              >
                <Play className="w-4 h-4" />
                Run
              </button>
              <button
                onClick={reset}
                className="flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-800 text-slate-100 hover:bg-slate-900"
              >
                <RefreshCcw className="w-4 h-4" />
                Clear
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3">
            <div className="text-slate-100 font-medium mb-2">Prompt / Output</div>
            <div className="min-h-[260px] rounded-lg border border-slate-800 bg-slate-900/30 p-3 text-slate-100 whitespace-pre-wrap">
              {output || "Pick a scenario and hit Run. You can paste this into Oracle / AI Insight."}
            </div>
            <div className="text-slate-500 text-xs mt-2">
              Tip: Use this as a structured prompt for your “Oracle” or AI insight feature.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Holodeck;
