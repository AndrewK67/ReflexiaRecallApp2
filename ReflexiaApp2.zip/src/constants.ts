// src/constants.ts
import type { ProfessionConfig, ProfessionId, ReflectionModel, CrisisProtocol } from "./types";
import { StageId } from "./types";

/** -----------------------------
 * Profession Config (fixed keys + standards)
 * ------------------------------ */

export const PROFESSION_CONFIG: Record<ProfessionId, ProfessionConfig> = {
  NONE: {
    label: "General",
    standards: [
      { id: "GEN-1", title: "Reflective practice", description: "Regular reflection to improve performance and wellbeing." },
      { id: "GEN-2", title: "Ethics & accountability", description: "Act with integrity and take responsibility for actions." },
      { id: "GEN-3", title: "Communication", description: "Clear, respectful communication with others." },
    ],
  },

  HEALTHCARE: {
    label: "Healthcare",
    standards: [
      { id: "HC-1", title: "Patient safety", description: "Prioritise safety and risk management." },
      { id: "HC-2", title: "Clinical reasoning", description: "Use evidence and judgement to decide next actions." },
      { id: "HC-3", title: "Documentation", description: "Accurate records, confidentiality, data protection." },
      { id: "HC-4", title: "Professional development", description: "CPD to maintain competence and improve outcomes." },
    ],
  },

  EDUCATION: {
    label: "Education",
    standards: [
      { id: "EDU-1", title: "Planning & progression", description: "Plan learning with clear progression and outcomes." },
      { id: "EDU-2", title: "Inclusive practice", description: "Support diverse needs, accessibility, safeguarding." },
      { id: "EDU-3", title: "Assessment for learning", description: "Use assessment to inform teaching and improve learning." },
      { id: "EDU-4", title: "Professional conduct", description: "Ethics, boundaries, and responsible practice." },
    ],
  },

  TEACHING: {
    label: "Teaching",
    standards: [
      { id: "TEACH-1", title: "Subject knowledge", description: "Secure knowledge and effective pedagogy." },
      { id: "TEACH-2", title: "Behaviour & culture", description: "Create a safe, positive learning environment." },
      { id: "TEACH-3", title: "Differentiation", description: "Adapt teaching to learners’ needs." },
      { id: "TEACH-4", title: "Reflect & improve", description: "Use reflection and feedback to improve practice." },
    ],
  },

  SOCIAL_CARE: {
    label: "Social Care",
    standards: [
      { id: "SC-1", title: "Safeguarding", description: "Protect vulnerable individuals, follow procedures." },
      { id: "SC-2", title: "Person-centred support", description: "Respect dignity, choice, and independence." },
      { id: "SC-3", title: "Multi-agency working", description: "Work with professionals, families, and services." },
      { id: "SC-4", title: "Professional boundaries", description: "Maintain healthy boundaries and confidentiality." },
    ],
  },

  SECURITY: {
    label: "Security",
    standards: [
      { id: "SEC-1", title: "Threat awareness", description: "Identify risks and maintain vigilance." },
      { id: "SEC-2", title: "De-escalation", description: "Use calm, lawful approaches to manage conflict." },
      { id: "SEC-3", title: "Incident reporting", description: "Accurate, timely reports and evidence handling." },
      { id: "SEC-4", title: "Legal compliance", description: "Work within policy, law, and duty of care." },
    ],
  },

  POLICING: {
    label: "Policing",
    standards: [
      { id: "POL-1", title: "Legitimacy & ethics", description: "Fairness, integrity, lawful decision-making." },
      { id: "POL-2", title: "Risk & safeguarding", description: "Protect life and manage risk proactively." },
      { id: "POL-3", title: "Evidence & recording", description: "Accurate notes, evidence preservation, disclosure." },
      { id: "POL-4", title: "Communication", description: "Clear engagement with public and partners." },
    ],
  },

  TRANSPORT: {
    label: "Transport",
    standards: [
      { id: "TR-1", title: "Safety & compliance", description: "Operate within rules, safety procedures, duty of care." },
      { id: "TR-2", title: "Customer service", description: "Respectful, helpful communication." },
      { id: "TR-3", title: "Situational awareness", description: "Assess environment, anticipate issues." },
      { id: "TR-4", title: "Incident response", description: "Follow protocols and document events." },
    ],
  },

  HOSPITALITY: {
    label: "Hospitality",
    standards: [
      { id: "HOS-1", title: "Service standards", description: "Consistent, high-quality guest experience." },
      { id: "HOS-2", title: "Teamwork", description: "Coordinate effectively with colleagues." },
      { id: "HOS-3", title: "Problem-solving", description: "Resolve issues calmly and professionally." },
      { id: "HOS-4", title: "Health & safety", description: "Food safety, cleanliness, compliance." },
    ],
  },
};

/** -----------------------------
 * Reflection Model Config
 * ------------------------------ */

export const MODEL_CONFIG: Record<string, ReflectionModel> = {
  ROLFE: {
    id: "ROLFE",
    title: "Rolfe",
    description: "What? So what? Now what?",
    stages: [
      { id: StageId.ROLFE_What, title: "What?", prompt: "What happened? Keep it factual.", placeholder: "Describe the situation…" },
      { id: StageId.ROLFE_SoWhat, title: "So what?", prompt: "Why does it matter? What did you feel/learn?", placeholder: "Meaning, impact, feelings…" },
      { id: StageId.ROLFE_NowWhat, title: "Now what?", prompt: "What will you do next? What would you change?", placeholder: "Next steps…" },
    ],
  },

  STAR: {
    id: "STAR",
    title: "STAR",
    description: "Situation, Task, Action, Result",
    stages: [
      { id: StageId.STAR_Situation, title: "Situation", prompt: "What was the situation?", placeholder: "Context…" },
      { id: StageId.STAR_Task, title: "Task", prompt: "What was your responsibility?", placeholder: "Your role…" },
      { id: StageId.STAR_Action, title: "Action", prompt: "What did you do?", placeholder: "Actions taken…" },
      { id: StageId.STAR_Result, title: "Result", prompt: "What happened? What changed?", placeholder: "Outcome…" },
    ],
  },

  SOAP: {
    id: "SOAP",
    title: "SOAP",
    description: "Subjective, Objective, Assessment, Plan",
    stages: [
      { id: StageId.SOAP_Subjective, title: "Subjective", prompt: "What did you observe/experience subjectively?", placeholder: "Subjective…" },
      { id: StageId.SOAP_Objective, title: "Objective", prompt: "What are the measurable facts?", placeholder: "Objective…" },
      { id: StageId.SOAP_Assessment, title: "Assessment", prompt: "What do you think is going on?", placeholder: "Assessment…" },
      { id: StageId.SOAP_Plan, title: "Plan", prompt: "What’s the plan?", placeholder: "Plan…" },
    ],
  },

  MORNING: {
    id: "MORNING",
    title: "Morning Check-in",
    description: "Set your intention for the day",
    stages: [
      { id: StageId.MORNING_Intention, title: "Intention", prompt: "What kind of person do you want to be today?", placeholder: "My intention is…" },
      { id: StageId.MORNING_Gratitude, title: "Gratitude", prompt: "What are you grateful for?", placeholder: "Today I'm grateful for…" },
      { id: StageId.MORNING_Focus, title: "Focus", prompt: "What’s your main focus?", placeholder: "My focus is…" },
    ],
  },

  EVENING: {
    id: "EVENING",
    title: "Evening Review",
    description: "Close the day well",
    stages: [
      { id: StageId.EVENING_Wins, title: "Wins", prompt: "What went well today?", placeholder: "Wins…" },
      { id: StageId.EVENING_Lessons, title: "Lessons", prompt: "What did you learn?", placeholder: "Lessons…" },
      { id: StageId.EVENING_Release, title: "Release", prompt: "What do you need to let go of?", placeholder: "I release…" },
    ],
  },
};

/** -----------------------------
 * Crisis Protocols
 * ------------------------------ */

export const CRISIS_PROTOCOLS: CrisisProtocol[] = [
  {
    category: "Immediate Safety",
    title: "Immediate Safety (Right Now)",
    steps: [
      { title: "Pause", body: "Stop what you're doing and take one slow breath in… and out." },
      { title: "Assess", body: "Are you in immediate danger? If yes, move to a safer location if possible." },
      { title: "Reach out", body: "Contact a trusted person nearby or emergency services if needed." },
    ],
    actionLabel: "Get help now",
  },
  {
    category: "Panic / Anxiety",
    title: "Panic / Anxiety Reset",
    steps: [
      { title: "Grounding", body: "Name 5 things you can see, 4 you can feel, 3 you can hear, 2 you can smell, 1 you can taste." },
      { title: "Breathing", body: "Breathe in 4, hold 4, out 6. Repeat 5 times." },
      { title: "Next step", body: "Do one small action: water, sit down, message someone." },
    ],
  },
  {
    category: "Other",
    title: "Stabilise & Choose Next Step",
    steps: [
      { title: "Name it", body: "What exactly is happening right now? One sentence only." },
      { title: "Support", body: "Who can you contact within the next 10 minutes?" },
      { title: "Small win", body: "Do one small helpful thing (drink water, step outside, write it down)." },
    ],
  },
];
