// src/services/geminiService.ts
// ReflectApp2 - Gemini service (no SDK). Safe fallback if no API key.
// Exports expected by the app:
// - analyzeReflection
// - getStageCoaching
// - askOracle

type GeminiGenerateResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
  error?: { message?: string };
};

const DEFAULT_MODEL = "gemini-1.5-flash";
const API_KEY = (import.meta.env.VITE_GEMINI_API_KEY as string | undefined) ?? "";
const MODEL = (import.meta.env.VITE_GEMINI_MODEL as string | undefined) ?? DEFAULT_MODEL;

function hasKey(): boolean {
  return API_KEY.trim().length > 0;
}

function extractText(json: GeminiGenerateResponse): string | null {
  const text =
    json?.candidates?.[0]?.content?.parts
      ?.map((p) => p?.text ?? "")
      .join("")
      .trim() ?? "";
  return text.length > 0 ? text : null;
}

async function callGemini(prompt: string): Promise<string> {
  if (!hasKey()) {
    return [
      "AI is currently OFF (missing VITE_GEMINI_API_KEY).",
      "",
      "Add your key to a local .env file, restart the dev server, and try again.",
      "Example:",
      "VITE_GEMINI_API_KEY=your_key_here",
      "VITE_GEMINI_MODEL=gemini-1.5-flash",
    ].join("\n");
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
    MODEL
  )}:generateContent?key=${encodeURIComponent(API_KEY)}`;

  const body = {
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.7,
      topP: 0.95,
      maxOutputTokens: 900,
    },
  };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    let msg = `Gemini request failed: ${res.status} ${res.statusText}`;
    try {
      const j = (await res.json()) as GeminiGenerateResponse;
      if (j?.error?.message) msg += `\n${j.error.message}`;
    } catch {
      // ignore
    }
    return msg;
  }

  const json = (await res.json()) as GeminiGenerateResponse;
  return extractText(json) ?? "Gemini returned no text. Try again with a bit more detail.";
}

/**
 * Reflection analysis for ReflectionFlow.tsx
 */
export async function analyzeReflection(
  reflectionText: string,
  mood?: string,
  profession?: string
): Promise<string> {
  const text = (reflectionText || "").trim();
  if (!text) return "Write a little more so I can analyze something meaningful.";

  const prompt = [
    "You are the ReflectApp2 Insight Guide.",
    "Return plain text only (no markdown).",
    "Be constructive, grounded, and concise.",
    "",
    `Mood (optional): ${mood || "unknown"}`,
    `Profession (optional): ${profession || "unknown"}`,
    "",
    "User reflection:",
    text,
    "",
    "Output structure:",
    "1) One-sentence summary",
    "2) What seems to be happening (2-4 bullets)",
    "3) Possible blind spots (1-3 bullets)",
    "4) Next best step (3 short actions)",
    "5) A short encouragement line",
  ].join("\n");

  return callGemini(prompt);
}

/**
 * Stage coaching used by stage-based UI (if present).
 */
export async function getStageCoaching(stage: string, reflectionText?: string): Promise<string> {
  const prompt = [
    "You are ReflectApp2's holographic Guide.",
    "Return plain text only (no markdown).",
    "Give coaching tailored to the user's current stage.",
    "",
    `Stage: ${stage}`,
    "",
    "If reflection text is provided, use it. Otherwise give generic guidance for the stage.",
    "Reflection:",
    (reflectionText || "").trim() || "(none provided)",
    "",
    "Output:",
    "- A short stage explanation (1-2 lines)",
    "- 3 questions to ask yourself",
    "- 3 micro-actions for today",
  ].join("\n");

  return callGemini(prompt);
}

/**
 * Oracle Q&A used by Oracle.tsx
 */
export async function askOracle(question: string, context?: string): Promise<string> {
  const q = (question || "").trim();
  if (!q) return "Ask me a question first.";

  const prompt = [
    "You are the ReflectApp2 Oracle.",
    "Return plain text only (no markdown).",
    "Tone: wise, practical, calm. No mysticism. No medical/legal certainty.",
    "",
    "Question:",
    q,
    "",
    "Context (optional):",
    (context || "").trim() || "(none)",
    "",
    "Respond with:",
    "1) A direct answer (2-5 lines)",
    "2) 3 clarifying questions the user could reflect on",
    "3) 3 practical next steps",
  ].join("\n");

  return callGemini(prompt);
}
